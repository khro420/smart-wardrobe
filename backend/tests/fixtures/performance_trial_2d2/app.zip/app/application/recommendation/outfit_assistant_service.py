"""Single-request Assistant integration; existing algorithms remain authoritative."""
from dataclasses import asdict
from fractions import Fraction
import hashlib
import json
import re
from time import perf_counter
from app.application.recommendation.recommendation_scorer import RecommendationScorer
from app.domain.value_objects.recommendation_persistence import RecommendationWrite, PersistenceConflict, WardrobeChanged


class CapturedPreferenceQuery:
    """One immutable, user-scoped read snapshot per ranking interaction."""
    def __init__(self, query):
        self.query, self.rows = query, None

    def get_active_preferences(self, user_id):
        if self.rows is not None:
            raise ValueError("Preference snapshot already consumed.")
        self.rows = tuple(self.query.get_active_preferences(user_id))
        return self.rows


class CapturedCandidateEngine:
    def __init__(self,engine):
        self.engine, self.session = engine, None

    def generate_candidates(self,user_id,request):
        self.session = self.engine.generate_candidates(user_id,request)
        return self.session


class OutfitAssistantService:
    def __init__(self, interpreter, engine, preference_query, repository, scorer_factory=RecommendationScorer):
        self.interpreter, self.engine = interpreter, engine
        self.preference_query, self.repository = preference_query, repository
        self.scorer_factory = scorer_factory

    def recommend(self, user_id, submission_key, request_text):
        if (not isinstance(user_id,str) or not user_id.strip() or not isinstance(submission_key,str)
                or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,199}",submission_key) is None
                or not isinstance(request_text,str) or not request_text.strip() or len(request_text)>500):
            return {"status":"InvalidInput","complete":False}
        stage, timings = "lookup", {}
        try:
            start = perf_counter()
            prior = self.repository.find_assistant_submission(user_id,submission_key,request_text)
            timings["lookup_seconds"] = perf_counter()-start
            if prior is not None:
                return self._success(prior,True,timings)
            stage = "interpretation"
            start = perf_counter()
            interpreted = self.interpreter.interpret(request_text)
            timings["nlp_seconds"] = perf_counter()-start
            if interpreted.status != "Supported":
                return {"status":interpreted.status,"reason":interpreted.reason,"complete":False}
            request = interpreted.structured_request
            captured = CapturedPreferenceQuery(self.preference_query)
            candidates = CapturedCandidateEngine(self.engine)
            stage = "ranking"
            start = perf_counter()
            ranked = self.scorer_factory(candidates,captured).rank(user_id,request,"compatibility_deferred")
            timings["ranking_seconds"] = perf_counter()-start
            if ranked.status != "Selected":
                return {"status":ranked.status,"complete":ranked.complete,"diagnostics":ranked.diagnostics,"timings":timings}
            if not ranked.complete or ranked.winner is None or ranked.scored_count<1 or captured.rows is None:
                return {"status":"ProcessingFailure","complete":False}
            score = ranked.winner.score
            if (score.profile_name != "compatibility_deferred" or score.compatibility.summary.state != "Unavailable"
                    or score.weights != (Fraction(7,10),Fraction(0),Fraction(3,10))):
                return {"status":"ProfileUnavailable","complete":False}
            preference_snapshot = [asdict(row) for row in captured.rows]
            preference_json = json.dumps(preference_snapshot,sort_keys=True,separators=(",",":"))
            provenance = {"assistant_policy":"phase5c-1.0.0","nlp_vocabulary":self.interpreter.vocabulary.version,
                "scoring_profile":score.profile_name,"scoring_policy":score.policy_version,
                "preference_consistency":"captured_at_ranking_read_not_commit_time",
                "preference_snapshot":preference_snapshot,"preference_snapshot_sha256":hashlib.sha256(preference_json.encode()).hexdigest(),
                "scored_count":ranked.scored_count,"diagnostics":ranked.diagnostics,
                "request_evaluator":type(candidates.session.evaluator).__name__,
                "suitability_policy":getattr(getattr(candidates.session.evaluator,"policy",None),"version",None),
                "structure_policy":self.engine.structural_engine.generator.policy.version,
                "mandatory_evaluation":asdict(ranked.winner.verified.evaluated.evaluation),
                "validity":"approved_minimum_mandatory_conditions_not_aesthetic_validation"}
            command = RecommendationWrite(user_id,"assistant",submission_key,json.dumps(asdict(request)),ranked.winner.verified.candidate,
                                          json.dumps(provenance),request_text,score)
            stage = "persistence"
            start = perf_counter()
            result,replayed = self.repository.persist_assistant(command)
            timings["persistence_seconds"] = perf_counter()-start
            return self._success(result,replayed,timings)
        except PersistenceConflict:
            return {"status":"IdempotencyConflict","complete":False}
        except WardrobeChanged:
            return {"status":"WardrobeChanged","complete":False}
        except (KeyboardInterrupt,GeneratorExit):
            return {"status":"Interrupted","complete":False}
        except Exception:
            return {"status":"PersistenceFailure" if stage in ("lookup","persistence") else "ProcessingFailure","complete":False}

    @staticmethod
    def _success(record,replayed,timings):
        # Retain legacy success fields at top level for existing consumers.
        return {**record,"status":"Selected","recommendation_status":record["status"],"complete":True,
                "replayed":replayed,"timings":timings,"recommendation":record}
