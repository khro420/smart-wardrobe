"""Outfit visualisation application services."""
