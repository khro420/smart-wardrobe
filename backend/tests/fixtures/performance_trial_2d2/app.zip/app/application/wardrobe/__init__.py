"""Digital Wardrobe application services."""
