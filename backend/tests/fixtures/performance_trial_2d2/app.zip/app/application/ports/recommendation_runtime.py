"""Composition-injected wardrobe acquisition boundary for Recommendation."""
from app.shared_contracts.confirmed_garment_query import ConfirmedGarmentQuery

_query: ConfirmedGarmentQuery | None = None


def configure_recommendation_query(query: ConfirmedGarmentQuery) -> None:
    global _query
    _query = query


def confirmed_garment_query() -> ConfirmedGarmentQuery:
    if _query is None:
        raise RuntimeError("Recommendation garment query was not configured at startup.")
    return _query
