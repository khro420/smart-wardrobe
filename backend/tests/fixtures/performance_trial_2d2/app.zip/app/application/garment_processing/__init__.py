"""Garment-analysis application services."""
