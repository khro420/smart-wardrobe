"""Immutable exact scores with unknown/NA distinct from numerical contribution."""
from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True)
class ScoreEvidence:
    name: str
    value: Fraction | None
    state: str
    observed: int = 0
    possible: int = 0
    reasons: tuple[str, ...] = ()

    def __post_init__(self):
        if not isinstance(self.name,str) or self.state not in ("Available","Partial","Unknown","NotApplicable","Unavailable","NoPreferences","NoSupportedPreferences"):
            raise ValueError("Invalid scoring evidence metadata.")
        if self.value is not None and (not isinstance(self.value,Fraction) or not 0 <= self.value <= 1):
            raise ValueError("Score must be an exact fraction in 0–1.")
        if (self.state in ("Available","Partial")) != (self.value is not None):
            raise ValueError("Only supported numerical evidence carries a score.")
        if any(isinstance(x,bool) or not isinstance(x,int) or x < 0 for x in (self.observed,self.possible)) or self.observed > self.possible:
            raise ValueError("Invalid evidence coverage counts.")
        if not isinstance(self.reasons,(list,tuple)) or any(not isinstance(x,str) for x in self.reasons):
            raise ValueError("Invalid evidence reasons.")
        object.__setattr__(self,"reasons",tuple(self.reasons))


@dataclass(frozen=True)
class ComponentScore:
    summary: ScoreEvidence
    details: tuple[ScoreEvidence, ...] = ()

    def __post_init__(self):
        if not isinstance(self.summary,ScoreEvidence) or not isinstance(self.details,(list,tuple)) or any(not isinstance(x,ScoreEvidence) for x in self.details):
            raise ValueError("Invalid component evidence.")
        object.__setattr__(self,"details",tuple(self.details))

    @property
    def contribution(self):
        return self.summary.value if self.summary.value is not None else Fraction(0)


_STANDARD_CONTRIBUTION = ComponentScore.contribution


def _integer_total_mismatch(total, weights, components):
    """Independent exact check; None selects the original arithmetic semantics.

    Only built-in Fraction/int arithmetic and plain immutable components are
    eligible. Subclasses retain their operators, properties and exception order.
    Every contribution is examined, including those with a zero weight.
    """
    if (type(total) is not Fraction or (type(weights) is not tuple and type(weights) is not list)
            or ComponentScore.contribution is not _STANDARD_CONTRIBUTION
            or any(type(w) is not Fraction for w in weights)
            or any(type(c) is not ComponentScore or type(c.summary) is not ScoreEvidence for c in components)):
        return None
    numerator, denominator = 0, 1
    for weight, component in zip(weights, components):
        value = component.contribution
        if type(value) is not Fraction:
            return None
        wn, wd, vn, vd = weight.numerator, weight.denominator, value.numerator, value.denominator
        if any(type(x) is not int for x in (wn, wd, vn, vd)) or wd <= 0 or vd <= 0:
            return None
        term_numerator, term_denominator = wn*vn, wd*vd
        numerator = numerator*term_denominator + term_numerator*denominator
        denominator *= term_denominator
    tn, td = total.numerator, total.denominator
    if type(tn) is not int or type(td) is not int or td <= 0:
        return None
    return tn*denominator != numerator*td


@dataclass(frozen=True)
class RecommendationScore:
    request_match: ComponentScore
    compatibility: ComponentScore
    preference: ComponentScore
    total: Fraction
    profile_name: str
    policy_version: str
    weights: tuple[Fraction, ...]

    def __post_init__(self):
        components = (self.request_match,self.compatibility,self.preference)
        if any(not isinstance(x,ComponentScore) for x in components) or not isinstance(self.total,Fraction) or not 0 <= self.total <= 1:
            raise ValueError("Invalid recommendation scores.")
        if not isinstance(self.weights,(list,tuple)) or len(self.weights) != 3 or any(not isinstance(w,Fraction) or not 0 <= w <= 1 for w in self.weights) or sum(self.weights) != 1:
            raise ValueError("Invalid score weights.")
        mismatch = _integer_total_mismatch(self.total,self.weights,components)
        if mismatch is None:
            mismatch = self.total != sum(w*c.contribution for w,c in zip(self.weights,components))
        if mismatch:
            raise ValueError("Total does not match component calculation.")
        if not isinstance(self.profile_name,str) or not self.profile_name or not isinstance(self.policy_version,str) or not self.policy_version:
            raise ValueError("Missing score provenance.")
        object.__setattr__(self,"weights",tuple(self.weights))
