"""Cross-subsystem contracts."""
