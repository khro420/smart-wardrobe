"""Independent Phase 5A SQLite writer/read model; not wired to live routes."""
from dataclasses import asdict
from fractions import Fraction
import hashlib
import json
import sqlite3
import uuid
from app.infrastructure.config import DATABASE_PATH
from app.infrastructure.persistence.postgresql_repository import utcnow
from app.infrastructure.persistence.confirmed_garment_query_adapter import SqliteConfirmedGarmentQuery
from app.domain.value_objects.recommendation_persistence import RecommendationWrite, PersistenceConflict, WardrobeChanged


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False,
                      default=lambda x: {"numerator": x.numerator, "denominator": x.denominator} if isinstance(x, Fraction) else asdict(x))


def request_fingerprint(operation, request_json, request_text):
    return hashlib.sha256(encode({"version": 1, "operation": operation,
        "request": json.loads(request_json), "request_text": request_text}).encode()).hexdigest()


class SqliteRecommendationRepository:
    def __init__(self, database_path=DATABASE_PATH, checkpoint=None):
        self.database_path = database_path
        self.checkpoint = checkpoint or (lambda stage, conn: None)

    def _connect(self):
        conn = sqlite3.connect(self.database_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def persist(self, command: RecommendationWrite):
        return self._persist(command)[0]

    def persist_homepage(self, command: RecommendationWrite):
        """Additive Homepage result/replay pair, resolved under the write lock."""
        if not isinstance(command, RecommendationWrite) or command.operation != "homepage":
            raise ValueError("Expected Homepage persistence command.")
        return self._persist(command)

    def _persist(self, command: RecommendationWrite):
        if not isinstance(command, RecommendationWrite):
            raise ValueError("Expected immutable persistence command.")
        # Fingerprint request identity, not nondeterministic selected result.
        fingerprint = request_fingerprint(command.operation, command.request_json, command.request_text)
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            if not conn.execute("SELECT 1 FROM users WHERE id=? AND account_status='active'", (command.user_id,)).fetchone():
                raise ValueError("Active authenticated owner required.")
            prior = conn.execute("SELECT fingerprint,recommendation_id FROM recommendation_submissions WHERE user_id=? AND operation=? AND submission_key=?",
                                 (command.user_id, command.operation, command.submission_key)).fetchone()
            if prior:
                if prior["fingerprint"] != fingerprint:
                    raise PersistenceConflict("Submission key payload conflict.")
                result = self._read(conn, command.user_id, prior["recommendation_id"])
                conn.commit()
                return result, True
            current = {g.garment_id: g for g in SqliteConfirmedGarmentQuery(conn).get_confirmed_available_garments(command.user_id)}
            for member in command.candidate.members:
                if current.get(member.garment.garment_id) != member.garment:
                    raise WardrobeChanged("Selected garment eligibility or snapshot changed.")
            self.checkpoint("revalidated", conn)
            identifier, now = str(uuid.uuid4()), utcnow()
            chat = str(uuid.uuid4()) if command.operation == "assistant" else None
            if chat:
                conn.execute("INSERT INTO nlp_chats VALUES (?,?,?,?,?,'completed',?,?)", (chat, command.user_id, command.request_text, "outfit_recommendation", command.request_json, now, now))
                self.checkpoint("chat", conn)
            score = command.score
            values = [float(c.summary.value) if c.summary.value is not None else None for c in (score.request_match, score.compatibility, score.preference)] + [float(score.total)] if score else [None]*4
            conn.execute("INSERT INTO recommendations VALUES (?,?,?,?,? ,?,NULL,?,?,?,?)", (identifier, command.user_id, chat, command.operation, "available", now, *values))
            self.checkpoint("recommendation", conn)
            for member in command.candidate.members:
                g = member.garment
                conn.execute("INSERT INTO recommendation_items VALUES (?,?,?,?,?)", (identifier, g.garment_id, member.role, member.item_order, now))
                self.checkpoint("item", conn)
                conn.execute("INSERT INTO recommendation_item_snapshots VALUES (?,?,?)", (identifier, g.garment_id, encode({"name": g.name, "category": g.category, "preferred_media_id": g.preferred_media_id})))
                self.checkpoint("snapshot", conn)
            conn.execute("INSERT INTO recommendation_metadata VALUES (?,?,?)", (identifier, command.provenance_json, encode(score) if score else None))
            self.checkpoint("metadata", conn)
            conn.execute("INSERT INTO recommendation_submissions VALUES (?,?,?,?,?)", (command.user_id, command.operation, command.submission_key, fingerprint, identifier))
            self.checkpoint("submission", conn)
            result = self._read(conn, command.user_id, identifier)
            self.checkpoint("before_commit", conn)
            conn.commit()
            return result, False
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def persist_assistant(self, command: RecommendationWrite):
        if not isinstance(command,RecommendationWrite) or command.operation != "assistant":
            raise ValueError("Expected Assistant command.")
        return self._persist(command)

    def find_assistant_submission(self,user_id,submission_key,request_text):
        conn = self._connect()
        try:
            conn.execute("BEGIN")
            if not conn.execute("SELECT 1 FROM users WHERE id=? AND account_status='active'",(user_id,)).fetchone():
                raise ValueError("Active authenticated owner required.")
            row = conn.execute("SELECT s.fingerprint,s.recommendation_id,c.extracted_entities_json FROM recommendation_submissions s JOIN recommendations r ON r.id=s.recommendation_id AND r.user_id=s.user_id JOIN nlp_chats c ON c.id=r.chat_id AND c.user_id=s.user_id WHERE s.user_id=? AND s.operation='assistant' AND s.submission_key=?",(user_id,submission_key)).fetchone()
            if row is None:
                return None
            if row["fingerprint"] != request_fingerprint("assistant",row["extracted_entities_json"],request_text):
                raise PersistenceConflict("Assistant submission payload conflict.")
            return self._read(conn,user_id,row["recommendation_id"])
        finally:
            conn.rollback()
            conn.close()

    def get(self, user_id, recommendation_id):
        conn = self._connect()
        try:
            conn.execute("BEGIN")
            return self._read(conn, user_id, recommendation_id)
        finally:
            conn.rollback()
            conn.close()

    def find_homepage_submission(self, user_id, submission_key):
        """Read-only retry recovery before generation, including stale results."""
        conn = self._connect()
        try:
            conn.execute("BEGIN")
            if not conn.execute("SELECT 1 FROM users WHERE id=? AND account_status='active'", (user_id,)).fetchone():
                raise ValueError("Active authenticated owner required.")
            prior = conn.execute("SELECT fingerprint,recommendation_id FROM recommendation_submissions WHERE user_id=? AND operation='homepage' AND submission_key=?", (user_id, submission_key)).fetchone()
            if prior is None:
                return None
            if prior["fingerprint"] != request_fingerprint("homepage", "{}", None):
                raise PersistenceConflict("Homepage submission payload conflict.")
            return self._read(conn, user_id, prior["recommendation_id"])
        finally:
            conn.rollback()
            conn.close()

    def _read(self, conn, user_id, identifier):
        row = conn.execute("SELECT r.*,c.request_text FROM recommendations r LEFT JOIN nlp_chats c ON c.id=r.chat_id AND c.user_id=r.user_id WHERE r.id=? AND r.user_id=?", (identifier, user_id)).fetchone()
        if not row:
            raise LookupError("Recommendation not found.")
        result = dict(row)
        eligible = {g.garment_id for g in SqliteConfirmedGarmentQuery(conn).get_confirmed_available_garments(user_id)}
        items = []
        for item in conn.execute("SELECT i.*,s.display_json FROM recommendation_items i LEFT JOIN recommendation_item_snapshots s USING(recommendation_id,garment_id) WHERE i.recommendation_id=? ORDER BY i.item_order", (identifier,)):
            value = {k: item[k] for k in ("garment_id", "garment_role", "item_order")}
            value.update(json.loads(item["display_json"]) if item["display_json"] else {"name": None, "category": None, "preferred_media_id": None})
            value.update(snapshot_available=item["display_json"] is not None, currently_eligible=item["garment_id"] in eligible)
            # Do not expose media for unavailable/inaccessible references.
            if not value["currently_eligible"]:
                value["preferred_media_id"] = None
            items.append(value)
        metadata = conn.execute("SELECT * FROM recommendation_metadata WHERE recommendation_id=?", (identifier,)).fetchone()
        result.update(items=items, provenance=json.loads(metadata["provenance_json"]) if metadata else None,
                      score_metadata=json.loads(metadata["score_json"]) if metadata and metadata["score_json"] else None)
        return result
