"""Concrete AI adapter implementations."""
