"""Protected media storage implementation."""
