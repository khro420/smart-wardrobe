from pydantic import BaseModel, ConfigDict, Field


class AssistantRecommendationCreate(BaseModel):
    model_config = ConfigDict(extra="allow")  # Legacy endpoint ignored extra keys.
    request_text: str = Field(strict=True,min_length=1,max_length=500)
    submission_key: str | None = Field(default=None,strict=True,min_length=1,max_length=200,pattern=r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$")
