"""Application API boundary."""
