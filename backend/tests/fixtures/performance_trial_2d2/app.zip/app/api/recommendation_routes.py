"""NLP chat and recommendation HTTP boundary from the report's application flow."""

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse
from app.api.homepage_models import HomepageRecommendationCreate
from app.application.ports.homepage_runtime import homepage_service
from app.application.ports.assistant_runtime import assistant_service
from app.api.assistant_models import AssistantRecommendationCreate

from app.application.recommendation import recommendation_service as recommendations
from app.domain.value_objects.requests import RecommendationCreate, RecommendationSaveAsOutfit
from app.infrastructure.security import current_user_id

router = APIRouter(prefix="/recommendations", tags=["NLP outfit recommendations"])


@router.get("/capabilities")
def capabilities(user_id: str = Depends(current_user_id), homepage=Depends(homepage_service), assistant=Depends(assistant_service)):
    """Allow the new UI to avoid posting to the disabled legacy Assistant."""
    return {"homepage_enabled":homepage is not None,"assistant_enabled":assistant is not None}


@router.post("/homepage")
def homepage(body: HomepageRecommendationCreate, user_id: str = Depends(current_user_id), service=Depends(homepage_service)):
    if service is None:
        return JSONResponse(status_code=404, content={"status": "IntegrationDisabled", "complete": False})
    result = service.recommend(user_id, body.submission_key)
    status = result["status"]
    code = 200
    if status == "Selected":
        code = 200 if result["replayed"] else 201
    elif status in ("IdempotencyConflict", "WardrobeChanged"):
        code = 409
    elif status in ("InvalidInput", "PolicyUnavailable"):
        code = 422
    elif status in ("ProcessingFailure", "PersistenceFailure", "Interrupted"):
        code = 503
    return JSONResponse(status_code=code, content=result)


@router.get("")
def list_all(user_id: str = Depends(current_user_id)) -> list[dict]:
    return recommendations.list_recommendations(user_id)


@router.post("", status_code=201)
def create(body: AssistantRecommendationCreate, user_id: str = Depends(current_user_id), service=Depends(assistant_service), pipeline: str | None = Query(default=None)):
    if pipeline not in (None,"integrated"):
        return JSONResponse(status_code=422,content={"status":"InvalidInput","outcome":"InvalidInput","complete":False})
    if service is None:
        if pipeline == "integrated":
            return JSONResponse(status_code=404,content={"status":"IntegrationDisabled","outcome":"IntegrationDisabled","complete":False})
        return recommendations.create_recommendation(user_id, body.request_text)
    if body.model_extra:
        return JSONResponse(status_code=422,content={"status":"InvalidInput","outcome":"InvalidInput","complete":False})
    result = service.recommend(user_id,body.submission_key,body.request_text)
    status = result["status"]
    code = 200
    if status == "Selected":
        code = 200 if result["replayed"] else 201
    elif status in ("InvalidInput","UnsupportedRequest","PolicyUnavailable","InvalidPreferenceData","ProfileUnavailable"):
        code = 422
    elif status in ("IdempotencyConflict","WardrobeChanged"):
        code = 409
    elif status in ("ProcessingFailure","ProcessingError","PersistenceFailure","Interrupted","InvalidScoringInput"):
        code = 503
    content = {**result,"outcome":status}
    if status == "Selected":
        content["status"] = result["recommendation_status"]
    return JSONResponse(status_code=code,content=content)


@router.post("/{recommendation_id}/save-as-outfit", status_code=201)
def save_as_outfit(recommendation_id: str, body: RecommendationSaveAsOutfit, user_id: str = Depends(current_user_id)) -> dict:
    return recommendations.save_as_outfit(recommendation_id, user_id, body.name)
