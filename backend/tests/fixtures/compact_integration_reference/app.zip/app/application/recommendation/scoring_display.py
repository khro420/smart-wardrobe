"""Versioned read-only API projection of stored evidence, never historical rescoring."""
from dataclasses import dataclass,asdict
import json
from typing import Literal
from app.application.recommendation.decision_score_codec import score_from_json
from app.application.recommendation.assistant_scoring_selection import DEFERRED,DECISION


@dataclass(frozen=True)
class ExactRatio:
    numerator: int
    denominator: int

    @classmethod
    def of(cls,value):
        return None if value is None else cls(value.numerator,value.denominator)


@dataclass(frozen=True)
class ScoringDisplay:
    kind: Literal["Decision","Deferred","Unavailable"]
    profile_name: str | None = None
    policy_version: str | None = None
    policy_hash: str | None = None
    raw_state: str | None = None
    basis: Literal["Computed","PartiallyConventional","FullyConventional","NoPairReference"] | None = None
    raw_value: ExactRatio | None = None
    decision_contribution: ExactRatio | None = None
    lower: ExactRatio | None = None
    upper: ExactRatio | None = None
    known: int | None = None
    possible: int | None = None
    pair_count: int | None = None
    structure: str | None = None
    weights: tuple[ExactRatio,...] | None = None
    reason: str | None = None
    version: str = "assistant-scoring-display-1.0.0"


def display_for_record(record):
    metadata=record.get("score_metadata")
    metadata=metadata if isinstance(metadata,dict) else {}
    provenance=record.get("provenance")
    provenance=provenance if isinstance(provenance,dict) else {}
    profile=metadata.get("profile_name") or provenance.get("scoring_profile")
    if (metadata.get("profile_name") and provenance.get("scoring_profile")
            and metadata["profile_name"] != provenance["scoring_profile"]):
        return ScoringDisplay("Unavailable",reason="StoredScoringIdentityMismatch")
    if profile == DECISION:
        try:
            score=score_from_json(json.dumps(metadata,allow_nan=False))
            c=score.compatibility;d=c.decision
            # Scalars are display-only but must not contradict authoritative metadata.
            raw=record.get("compatibility_score")
            if (raw is None)!=(c.summary.value is None) or (raw is not None and raw!=float(c.summary.value)):
                raise ValueError("Stored raw scalar contradicts exact metadata.")
            return ScoringDisplay("Decision",profile,score.policy_version,d.policy_hash,c.summary.state,d.basis,
                ExactRatio.of(c.summary.value),ExactRatio.of(d.value),ExactRatio.of(d.lower),ExactRatio.of(d.upper),
                d.known_count,d.atomic_count,d.pair_count,d.structure,tuple(ExactRatio.of(w) for w in score.weights))
        except (ValueError,TypeError,KeyError,AttributeError,ZeroDivisionError):
            return ScoringDisplay("Unavailable",profile_name=profile,reason="StoredDecisionMetadataUnavailable")
    if profile == DEFERRED:
        if record.get("compatibility_score") is not None:
            return ScoringDisplay("Unavailable",profile_name=profile,reason="StoredDeferredMetadataInconsistent")
        return ScoringDisplay("Deferred",profile_name=profile,raw_state="Unavailable")
    return ScoringDisplay("Unavailable",reason="LegacyOrUnsupportedScoringMetadata")


def with_scoring_display(record):
    return {**record,"scoring_display":asdict(display_for_record(record))}
