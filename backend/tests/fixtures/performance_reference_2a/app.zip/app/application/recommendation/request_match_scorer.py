from fractions import Fraction
from app.application.recommendation.garment_evidence_mapper import GarmentEvidenceMapper
from app.domain.value_objects.scored_candidate import VerifiedScoringInput
from app.domain.value_objects.recommendation_score import ScoreEvidence,ComponentScore


class RequestMatchScorer:
    def __init__(self,mapper=None):
        self.mapper = mapper or GarmentEvidenceMapper()

    def score(self,verified):
        if not isinstance(verified,VerifiedScoringInput):
            raise ValueError("Verified scoring input required.")
        request = verified.request
        details = []
        for field in ("garment_categories","colours","style","occasion","formality"):
            if getattr(request,field) is None:
                continue
            if field == "style":
                base = [member for member in verified.candidate.members if member.role != "outerwear"]
                evidence = [self.mapper.classify(member.garment).style for member in base]
                matched = sum(request.style in item.values for item in evidence)
                known = sum(item.state == "Known" for item in evidence)
                reasons = tuple(item.state.lower()+":"+member.garment.garment_id for member,item in zip(base,evidence))
                details.append(ScoreEvidence(field,Fraction(matched,len(base)),"Available" if known == len(base) else "Partial",known,len(base),reasons))
            else:
                details.append(ScoreEvidence(field,Fraction(1),"Available",1,1))
        if not details:
            return ComponentScore(ScoreEvidence("request_match",None,"NotApplicable"))
        return ComponentScore(ScoreEvidence("request_match",sum(x.value for x in details)/len(details),"Partial" if any(x.state == "Partial" for x in details) else "Available",sum(x.observed for x in details),sum(x.possible for x in details)),tuple(details))
