from fractions import Fraction
from dataclasses import replace
from app.application.nlp.vocabulary import Vocabulary
from app.application.recommendation.garment_evidence_mapper import GarmentEvidenceMapper
from app.application.recommendation.suitability_evidence_mapper import SuitabilityEvidenceParser
from app.domain.value_objects.scored_candidate import VerifiedScoringInput
from app.domain.value_objects.preference_snapshot import NormalizedPreferenceSet
from app.domain.value_objects.recommendation_score import ScoreEvidence,ComponentScore


class PreferenceScorer:
    def __init__(self,mapper=None):
        self.mapper = mapper or GarmentEvidenceMapper()
        self.suitability = SuitabilityEvidenceParser()
        self.vocabulary = Vocabulary.load()
        self._prepared = None
        self._empty = {state: ComponentScore(ScoreEvidence("preference",None,state))
                       for state in ("NoPreferences","NoSupportedPreferences")}

    def _prepare(self, preferences):
        # NormalizedPreferenceSet and its nested values are immutable. Identity
        # scopes reuse to this exact user-owned snapshot; no cross-request cache.
        if self._prepared is None or self._prepared[0] is not preferences:
            facts = []
            for preference in preferences.preferences:
                if preference.preference_type == "garment_categories":
                    allowed = set()
                    for item in preference.values:
                        allowed.update(self.vocabulary.groups[item.value] if item.kind == "group" else (item.value,))
                    facts.append(frozenset(allowed))
                elif preference.preference_type in ("colours","styles"):
                    facts.append(frozenset(preference.values))
                else:
                    facts.append(None)
            self._prepared = (preferences,tuple(facts),sum(p.importance for p in preferences.preferences))
        return self._prepared[1:]

    def score(self,verified,preferences):
        if not isinstance(verified,VerifiedScoringInput) or not isinstance(preferences,NormalizedPreferenceSet) or preferences.user_id != verified.user_id:
            raise ValueError("Verified user-scoped scoring inputs required.")
        if not preferences.preferences:
            state = "NoSupportedPreferences" if preferences.diagnostics else "NoPreferences"
            return self._empty[state]
        prepared, denominator = self._prepare(preferences)
        members = verified.candidate.members
        details = []
        for preference, matching_values in zip(preferences.preferences,prepared):
            kind,values = preference.preference_type,preference.values
            if kind == "garment_categories":
                match = any(item.garment.category in matching_values for item in members)
                detail = ScoreEvidence(kind,Fraction(int(match)),"Available",1,1)
            elif kind in ("colours","styles"):
                selected = [item for item in members if kind == "colours" or item.role != "outerwear"]
                evidence = [getattr(self.mapper.classify(item.garment),"colour" if kind == "colours" else "style") for item in selected]
                matched = sum(not matching_values.isdisjoint(item.values) for item in evidence)
                known = sum(item.state == "Known" for item in evidence)
                if kind == "colours" and matched:
                    detail = ScoreEvidence(kind,Fraction(1),"Available",known,len(evidence))
                elif known == 0 and matched == 0:
                    detail = ScoreEvidence(kind,None,"Unknown",0,len(evidence))
                else:
                    value = Fraction(int(matched>0)) if kind == "colours" else Fraction(matched,len(evidence))
                    detail = ScoreEvidence(kind,value,"Available" if known == len(evidence) else "Partial",known,len(evidence))
                detail = replace(detail,reasons=tuple(item.state.lower()+":"+member.garment.garment_id for member,item in zip(selected,evidence)))
            else:
                evidence = [self.suitability.parse(item.garment) for item in members]
                states = [[item.state_for("formality",value) for item in evidence] for value in values]
                if any(all(state == "Pass" for state in row) for row in states):
                    detail = ScoreEvidence(kind,Fraction(1),"Available",1,1)
                elif all(any(state == "Fail" for state in row) for row in states):
                    detail = ScoreEvidence(kind,Fraction(0),"Available",1,1)
                else:
                    detail = ScoreEvidence(kind,None,"Unknown",0,1)
                detail = replace(detail,reasons=tuple(item.source_state.lower()+":"+member.garment.garment_id for member,item in zip(members,evidence)))
            details.append(detail)
        value = sum(p.importance*(detail.value or Fraction(0)) for p,detail in zip(preferences.preferences,details))/denominator
        if all(detail.value is None for detail in details):
            return ComponentScore(ScoreEvidence("preference",None,"Unknown",0,sum(x.possible for x in details)),tuple(details))
        return ComponentScore(ScoreEvidence("preference",value,"Available" if all(x.state == "Available" for x in details) else "Partial",sum(x.observed for x in details),sum(x.possible for x in details)),tuple(details))
